package com.coreJava;

public class Inheritance1 extends Inheritance{  
		 int bonus=10000;  
		 public static void main(String args[]){  
		   Inheritance1 p= new Inheritance1();  
		   System.out.println("Programmer salary is:"+p.salary);  
		   System.out.println("Bonus of Programmer is:"+p.bonus);  
		}  
		} 

