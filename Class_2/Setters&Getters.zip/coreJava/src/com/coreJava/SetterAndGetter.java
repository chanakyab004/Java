package com.coreJava;

public class SetterAndGetter {
	 public static void main(String args[]) {
		   SetterAndGetter chan = new SetterAndGetter();
		   chan.setName("James");
		   chan.setAge(20);
		   chan.setIdNum("12343");

		      System.out.print("Name : " + chan.getName() + " Age : " + chan.getAge()+ "  IdNum : " + chan.getIdNum());
		   }
		   private String name;
		   private String idNum;
		   private int age;
		   public String getName() {
				return name;
			}
			public void setName(String name) {
				this.name = name;
			}
			public String getIdNum() {
				return idNum;
			}
			public void setIdNum(String idNum) {
				this.idNum = idNum;
			}
			public int getAge() {
				return age;
			}
			public void setAge(int age) {
				this.age = age;
			}
		  
		
			}

