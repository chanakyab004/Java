package com.coreJava;

public class PassByReference {

	public static void main(String args[]) {
		Animals a = new Animals("Lion");

		System.out.println("Before Modify: " + a);
		modify(a);
		System.out.println("After Modify: " + a);
	}

	public static void modify(Animals animal) {
		animal.setName("Tiger");
	}

}

class Animals {
	String name;

	public Animals(String name) {
		this.name = name;
	}

	public String toString() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}

