package com.coreJava;

public class interface1 implements Interfaces
	{
	  public void method1()
	  {
	      System.out.println("implementation of method1");
	  }
	  public void method2()
	  {
	      System.out.println("implementation of method2");
	  }
	  public static void main(String arg[])
	  {
		  Interfaces obj = new interface1();
	      obj. method1();
	  }
	}

