package com.coreJava;

public class overriding1 {

		   public static void main(String args[]) {
			   overriding a = new overriding();   // Animal reference and object
			   overriding b = new Dog();   // Animal reference but Dog object

		      a.move();   // runs the method in Animal class
		      b.move();   // runs the method in Dog class
		   }
		}


