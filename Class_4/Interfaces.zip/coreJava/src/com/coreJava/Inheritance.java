package com.coreJava;

public class Inheritance{  
	 float salary=40000;  
	}  
	
