package com.coreJava;

public class overriding {
	   public void move() {
	      System.out.println("Animals can move");
	   }
	}

	class Dog extends overriding {
	   public void move() {
	      System.out.println("Dogs can walk and run");
	   }
	}

	