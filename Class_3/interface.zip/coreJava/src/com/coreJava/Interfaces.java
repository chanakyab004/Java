package com.coreJava;

public interface Interfaces {

	   public void method1();
	   public void method2();
	}
	

